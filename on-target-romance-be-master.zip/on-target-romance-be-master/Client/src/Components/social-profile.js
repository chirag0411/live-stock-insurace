import React from 'react';
import SelectBox from 'select-box';
import Text from 'text-box'; 
const SocialProfile = (props) => [
    <div className="lft">
        <div className="form-group">
            <SelectBox />
        </div>
    </div>
    ,
    <div className="rght">
        <div className="form-group">

        </div>
    </div>

];

export default SocialProfile;
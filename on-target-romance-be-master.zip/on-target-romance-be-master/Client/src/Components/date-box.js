import React from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
 
const DateBox = (props) =>(
    <DatePicker 
        placeholder={props.attributes.placeholder} 
        selected={props.attributes.value?new Date(props.attributes.value):new Date()} 
         className="form-control"
        onChange={(date) => props.IsUnderCustom ? 
            props.onCustomHandler(date.toDateString(), props.index, props.parentIndex) : 
            props.onChangeDateHandler(date.toDateString(), props.index, props.parentIndex)} 
     />
);
export default DateBox;
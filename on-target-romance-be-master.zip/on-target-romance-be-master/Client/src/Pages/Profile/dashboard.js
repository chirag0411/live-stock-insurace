import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import Logo from '../../Components/left-logo';
import TextBox from '../../Components/text-box';
import SelectBox from '../../Components/select-box';
import FileBox from '../../Components/file-box';
import DateBox from '../../Components/date-box';
import { HashLoader } from 'react-spinners';
import { css } from '@emotion/core';
import { setupEvent } from '../../Actions/event-setup';
import { notify } from 'react-notify-toast';
import { stat } from 'fs';
import { Route} from 'react-router-dom';
//import './dashboard.css'

class Dashboard extends Component {
    constructor(props) {
      super(props);
       this.state = {
        formJSON: [],
        event: null,
        myevents: false
      }
      this.props.setupEvent();
      this.onChangeHandler = this.onChangeHandler.bind(this);
      this.onCheckboxChangeHandler = this.onCheckboxChangeHandler.bind(this);
      this.onCustomChangeHandler = this.onCustomChangeHandler.bind(this);
      this.onChangeFileHandler = this.onChangeFileHandler.bind(this);
      this.onSubmitFormHandler = this.onSubmitFormHandler.bind(this);
      this.getCustomElementObject = this.getCustomElementObject.bind(this);
      this.addMoreLinkHandler = this.addMoreLinkHandler.bind(this);
      this.addMoreServiceHandler = this.addMoreServiceHandler.bind(this);
    }
  
  
    //======================= On Change Handlers ================
    handleMyEvents(event) {
      this.setState({
        myevents: event.target.checked
      });
    }
    onChangeHandler(value, index) { 
      let data = this.state.formJSON;
      data[index].value = value;
      this.setState({ formJSON: data });
    }
    onCheckboxChangeHandler(value, parentIndex) {
      let data = this.state.formJSON;
      if(data[parentIndex].value.includes(value)) {
        data[parentIndex].value = data[parentIndex].value.replace(value, "");
      }
      else{
        data[parentIndex].value += data[parentIndex].value.concat(value);
      }
  
      // if(data[parentIndex].value.contains(value))
      // {
      //   data[parentIndex].value = data[parentIndex].value.replace(data[parentIndex].value).trim(",");
      // }
      // else{
      //   data[parentIndex].value += "," + value;
      // } 
      this.setState({ formJSON: data });
    }
  
    onCustomChangeHandler(value, index, parentIndex) {
      let data = this.state.formJSON;
      data[parentIndex].children[index].value = value;
      this.setState({ formJSON: data });
    }
  
    onChangeFileHandler(file, acceptedSize) {
      if(parseInt(acceptedSize) * 1000 <= parseInt(file.size)){
        notify.show("File size is bigger than max size. Profile will be saved without Image.", "custom", 5000, { background: '#f8d7da', text: "#721c24" });
        return;
      }
      this.setState({ profile: file });
    }
  
    onSubmitFormHandler(e, history) {
       e.preventDefault();
      history.push("/setup-event");
    }
  
    addMoreLinkHandler(parentIndex, index) {
      let data = this.state.formJSON;
      data[parentIndex].children.push(data[parentIndex].children[index]);
      let el = {
        "tag": "input",
        "type": "text",
        "className": "form-control in_form_control",
        "placeholder": "link",
        "value": "",
        "validation": false,
        "name": ""
      };
      data[parentIndex].children[index] = el;
      data[parentIndex].children[index].name = data[parentIndex].linkname + (parseInt(data[parentIndex].links) + 1);
      data[parentIndex].links = parseInt(data[parentIndex].links) + 1;
  
      this.setState({ formJSON: data });
    }
  
    addMoreServiceHandler(parentIndex, index) {
      let data = this.state.formJSON;
      //data[parentIndex].children.push(data[parentIndex].children[index]);
      let el=data[parentIndex].children[index];
      let el1 = {"tag": "date", "value": "", "name":""};
      let el2 = {"tag": "service", "name": "", "type": "text", "value": "", "className": "form-control", "validation": "false", "placeholder": "Service"};
       
      data[parentIndex].children[index] = el1;
      data[parentIndex].children[index].name = "date_" + (parseInt(data[parentIndex].service) + 1);
      data[parentIndex].children.push(el2);
      data[parentIndex].children[index+1].name = "service_" + (parseInt(data[parentIndex].service) + 1);
      data[parentIndex].service = parseInt(data[parentIndex].service) + 1;
      data[parentIndex].children.push(el);
      this.setState({ formJSON: data });
    }
    //======================= On Change Handlers ENDS ================
  
  
    //======================= Common functions ====================
  
    getJSONFormData() {
      const formData = new FormData();
      this.state.formJSON.map(el => {
        if (el.name) {
          if (el.tag === "file")
            formData.append(el.name, this.state.profile);
          else if (el.tag === "custom") {
  
            let data = this.getCustomElementObject(el.children);
  
            formData.append(el.name, data);
          }
          else
            formData.append(el.name, el.value);
        }
      });
      return formData;
    }
  
    getCustomElementObject(children) {
      let data = {};
      children.map(el => {
        if (el.name) {
          data[el.name] = el.value;
        }
      });
      return JSON.stringify(data);
    }
  
    //======================= Common functions ENDS ====================
  
    //======================= Custom DOM Providers ================
   
    //======================= Custom DOM Providers ENDS ================
  
  
    //======================= Custom Component Providers ================
  
    
  
    //======================= Custom Component Providers ENDS ================
  
     
  
  
    //===================== RENDER ==========================
    render() {
      if (this.props.loading) {
        return (<div className='sweet-loading'>
          <HashLoader
            sizeUnit={"px"}
            size={100}
            color={'#1F1F1F'}
            loading={true}
          />
        </div>)
      }
      return (
        <>
          <div style={{ backgroundColor: "#1f1f1f" }}>
            <div className="container-fluid">
              <div className="row">
                <Logo />
                <div className="main_right author_profile" style={{minHeight:1000+'px'}}>
                <div className={this.state.myevents ? "navigation bg-light" : "navigation bg-dark"}>
                <nav className={this.state.myevents ? "navbar navbar-expand-lg navbar-light bg-light" : "navbar navbar-expand-lg navbar-light bg-dark"}>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span className="navbar-toggler-icon"></span>
                    </button>
                  
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul className="navbar-nav mr-auto">
                        <li className="nav-item active">
                            <a className="nav-link" href="#">Home</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Calendar</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Event filter</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">LISTS</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">VENDORS</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">daily task</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">PROFILE</a>
                        </li>
                      </ul>
                    </div>
                  </nav>
                  <div className="noti_setting"><a className="notification" href="#">4</a>
                  <a href="#" style={{ marginRight: "40px" }}><img src = {require("../../Utils/Assets/setting_icon.png")} alt="setting"/></a>
                    <a href="/">
                    <img src = {require("../../Utils/Assets/logout_icon.png")} alt="logout" onClick={() => { localStorage.removeItem("token"); return (<Redirect to="/" push />) }}/></a>
                 
                  </div>
            </div>
            
            <div className="filter_row">
                <div className="row">
                    <div className="col-sm-12">
                        
                    </div>
                </div>
                <div className="filter_options">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="toggle_switch">
                                <span className="yes_no">Dark</span>
                                <label className="switch">
                                    <input type="checkbox" name="myevents" onChange={this.handleMyEvents.bind(this)}  />
                                    <span className="slider round"></span>
                                </label>
                                <span className="yes_no">Light</span>
                            </div>
                            <div className="sport">
                                <a href="#">
                                    <span>Sort</span>
                                    <img src = {require("../../Utils/Assets/sort_icon.png")} alt="sort-icon" />
                                </a>
                            </div>
                            <div className="new_filter">
                                <a href="#">
                                    <img src = {require("../../Utils/Assets/cup_icon.png")} alt="cup-icon" />
                                </a>
                            </div>
                            <div className="search_box">
                                <form>
                                    <input type="text" placeholder="Search" name="search" />
                                    <button type="submit"><img src ={require("../../Utils/Assets/search_icon.png")} alt="search-icon" /></button>
                                </form>
                            </div>
                            <div className="calender_list">
                                <a className="calender" href="#">Calendar View</a><span>|</span><a className="list" href="#">List View</a>
                            </div>
                        </div>
                         </div>







        </div>
    </div>
     <Route render={({ history}) => (
    <form className="form_custom" onSubmit={(e)=>(this.onSubmitFormHandler(e ,history))}>
    <div className="form-group">
                  <button type="submit" className="btn btn_save_bt">Setup Event</button>

                  </div>
    </form>
    )}></Route>
    </div>
              </div>
            </div>
          </div>
        </>);
  
    }
  
  componentDidMount() {
      this.props.setupEvent();
    }
   componentWillReceiveProps() {
    this.setState({ formJSON: this.props.formJSON });
    }
  
  }
const mapStateToProps = (state) => {
    return {
        loading : state.eventLoading
    }
  };
  
  const mapDispatchToProps = (dispatch) => {
     return {
      setupEvent: () => dispatch(setupEvent()),
     };
  };
  
  
  export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
  
  
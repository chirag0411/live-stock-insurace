import React,{Component} from 'react';
export default class Profile extends Component{

    render(){
        console.log("in profile");
        return(<h2>WelCome to use Profile:</h2>);
    }
}
import React, { Component, Suspense } from 'react';
import { css } from '@emotion/core';
import { HashLoader } from 'react-spinners';
import { connect } from 'react-redux';
import {
  HashRouter,Redirect,
  Route,Switch 
} from 'react-router-dom'
import { authenticate } from './Actions/index';
import Landing from './Pages/Landing/landing';
import Login from './Pages/Login/login';
import SignUp from './Pages/SignUp/signup';
import Event from './Pages/Event/event';
import Dashboard  from './Pages/Profile/dashboard';
import './App.css';

const override = css`
    position:fixed;
    margin-top: 15%;
    left: 45%;
`;

class App extends Component {
  constructor(props){
    super(props);
    this.state={user:""}
  }


  render() {
    if (this.props.status) {
      return (  <div className='sweet-loading'>
      <HashLoader
      css={override}
        sizeUnit={"px"}
        size={100}
        color={'#1F1F1F'}
        loading={true}
      />
    </div>);
    }
    else {
        if(!localStorage.getItem("token")){
          return (
            <HashRouter>
              <Switch>
                <Route exact path="/" component={Landing} />
                <Route exact path="/log-in" component={Login} />
                <Route exact path="/sign-up" component={SignUp} />
                <Route path="*" render={()=><Redirect to="/" push/>} />
              </Switch>
            </HashRouter>
          );
        }else{
          return(
          <HashRouter>
            <div>
              <Route exact path="/" render={()=><Redirect to="/user" push/>} />
              <Route exact path="/log-in" render={()=><Redirect to="/user" push/>} />
              <Route exact path="/sign-up" component={SignUp} />
              <Route exact path="/setup-event" component={Event} />
              <Route exact path="/dashboard" component={Dashboard} />
              <Route  path="/user" component={Home} />

            </div>
          </HashRouter>)
        }
        
    }
  }
};

const LazyHome = React.lazy(() => import('./Pages/Home/home'));
const Home = () => (
  <Suspense fallback={<div></div>}>
    <LazyHome />
  </Suspense>
);
 
const mapStateToProps = (state) => {
  return {
    status: state.userloading,
    error: state.usererror,
    token:state.userlists
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchData: (url) => dispatch(authenticate(url))
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(App);
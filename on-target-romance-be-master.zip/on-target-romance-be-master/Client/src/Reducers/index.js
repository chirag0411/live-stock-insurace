import {combineReducers} from 'redux';
import {userlists,userloading,usererror,signuppage,signuploading} from './users';
import {profileError,profileLoading,profileData, userType} from './profile';
import { eventError,eventLoading,eventData } from './event'
export default combineReducers({
    userlists,
    userloading,
    usererror,
    signuppage,signuploading,
    profileError,profileLoading,profileData, userType,
    eventError,eventLoading,eventData
});
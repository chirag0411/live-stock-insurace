self.__precacheManifest = [
  {
    "revision": "e4c5039418de079ad073",
    "url": "/static/js/runtime~main.e4c50394.js"
  },
  {
    "revision": "af336b4c616cdd9e0f5e",
    "url": "/static/css/main.d88995d1.chunk.css"
  },
  {
    "revision": "d7461584894d1856728eced419479eab",
    "url": "/static/media/logout_icon.d7461584.png"
  },
  {
    "revision": "c66cc08561b451fc6973",
    "url": "/static/js/1.c66cc085.chunk.js"
  },
  {
    "revision": "0a859cdf8f29c1a2fb1f8e2739f66906",
    "url": "/static/media/setting_icon.0a859cdf.png"
  },
  {
    "revision": "a5e9a725f46ede8d7ade",
    "url": "/static/js/2.a5e9a725.chunk.js"
  },
  {
    "revision": "af336b4c616cdd9e0f5e",
    "url": "/static/js/main.af336b4c.chunk.js"
  },
  {
    "revision": "b79bb881a2300cdf0bf1ce5f778ff417",
    "url": "/static/media/logo_2.b79bb881.png"
  },
  {
    "revision": "023b62527fb2579f1a2dfb79a4acd73d",
    "url": "/static/media/minus.023b6252.png"
  },
  {
    "revision": "a5e9a725f46ede8d7ade",
    "url": "/static/css/2.43a2b1a4.chunk.css"
  },
  {
    "revision": "c66cc08561b451fc6973",
    "url": "/static/css/1.9a1ccf28.chunk.css"
  },
  {
    "revision": "10436d1920d1a64bbc064a39fd06379b",
    "url": "/index.html"
  }
];
// models
const CommonQueryModel = require('../models/commonQueryModel');

// Add new event
module.exports.addNewEvent = (req, res) => {
    req.body.event_details = JSON.parse(req.body.event_details);

    if (req.file && Object.keys(req.file).length > 0) {
        for (let i = 0; i < req.body.event_details.length; i += 1) {
            if (req.body.event_details[i].type === 'file') {
                req.body.event_details[i].value = req.file.path.replace('static', '');
            }
        }
    }

    return CommonQueryModel.addNewRecord(
        [
          {
            user_id: req.id,
            event_details: JSON.stringify(req.body.event_details),
            event_type: req.body.event_type
          },
        ],
        'events'
    )
    .then(() => {
      return res.status(200).json({
          message: "Event creted successfully"
      })
    })
    .catch((error) => {
        return res.status(error.status ? error.status : 500).json({
            message: error.message || "Internal server error"
        });
    })
};

// Fetch single event
module.exports.getSingleEventDetails = (req, res) => {
    return CommonQueryModel.selectRecord(
        ['event_details', 'created_date', 'event_type', 'updated_date'],
        [
            {
                key: 'user_id',
                value: req.id
            },
            {
                key: 'id',
                value: req.params.eventId
            }
        ],
        'events'
    )
    .then((events) => {
        if (events && events.length) {
            events[0]['event_details'] = JSON.parse(events[0]['event_details']);
            return res.status(200).json({
                message: "Event detail fetched",
                result: {
                    event: events[0]
                }
            })
        } else {
            throw ({
                status: 403,
                message: "Event not found"
            });
        }
    })
    .catch((error) => {
        return res.status(error.status ? error.status : 500).json({
            message: error.message || "Internal server error"
        });
    })
};

// Fetch all the events of particular user
module.exports.getEventsByUser = (req, res) => {
    return CommonQueryModel.selectRecord(
        ['id', 'event_details', 'created_date', 'event_type', 'updated_date'],
        [
            {
                key: 'user_id',
                value: req.id
            }
        ],
        'events',
        'created_date'
    )
    .then(async (events) => {      
        return res.status(200).json({
            message: "Event fetched successfully",
            result: {
                events: events.map((singleEvent) => {
                    singleEvent['event_details'] = JSON.parse(singleEvent['event_details']);
                    return singleEvent;
                })
            }
        });
    })
    .catch((error) => {
        return res.status(error.status ? error.status : 500).json({
            message: error.message || "Internal server error"
        });
    })
};

// Delete single event
module.exports.deleteEvent = (req, res) => {
    return CommonQueryModel.selectRecord(
        ['created_date'],
        [
            {
                key: 'user_id',
                value: req.id
            },
            {
                key: 'id',
                value: req.params.eventId
            }
        ],
        'events'
    )
    .then((events) => {
        if (events && events.length) {
            return CommonQueryModel.deleteRecord(
                [
                    {
                        key: 'id',
                        value: req.params.eventId
                    },
                    {
                        key: 'user_id',
                        value: req.id
                    }
                ],
                'events'
            )    
        } else {
            throw ({
                status: 403,
                message: "Event not found. May be alredy deleted"
            });
        }
    })
    .then(() => {
        return res.status(200).json({
            message: "Event deleted",
        })
    })
    .catch((error) => {
        return res.status(error.status ? error.status : 500).json({
            message: error.message || "Internal server error"
        });
    })
}

// Update event
module.exports.updateEvent = (req, res) => {
    return CommonQueryModel.selectRecord(
        ['created_date'],
        [
            {
                key: 'user_id',
                value: req.id
            },
            {
                key: 'id',
                value: req.params.eventId
            }
        ],
        'events'
    )
    .then((events) => {
        if (events && events.length) {
            return CommonQueryModel.updateRecord(
                { event_details: req.body.event_details, event_type: req.body.event_type },
                [
                    {
                        key: 'id',
                        value: req.params.eventId,
                    },
                    {
                        key: 'user_id',
                        value: req.id
                    },
                ],
                'events'
            )
        } else {
            throw ({
                status: 403,
                message: "Event not found"
            });
        }
    })
    .then(() => {
        return res.status(200).json({
            message: "Event updated"
        });
    })
    .catch((error) => {
        return res.status(error.status ? error.status : 500).json({
            message: error.message || "Internal server error"
        });
    })
};
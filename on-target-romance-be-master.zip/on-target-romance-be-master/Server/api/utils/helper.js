// const fse = require('fs-extra');
// const responseCode = require('../../constant/response_constant');

// module.exports.removeSingleFile = filePath => fse.remove(filePath);

// module.exports.removeFiles = (fileArray) => {
//   const deletedImages = fileArray.map(key => this.removeSingleFile(key));

//   return Promise.all(deletedImages);
// };

// module.exports.buildSuccessResponse = (statusCode, message, resource, uri, attribute_key = '', attribute_value = '') => {
//   const response = {
//     status: 'success',
//     statusCode,
//     message,
//     resource,
//     uri,
//   };

//   if (attribute_key && attribute_value) {
//     response.attribute = {
//       [attribute_key]: attribute_value,
//     };
//   }
//   return response;
// };

// module.exports.buildErrorResponse = (statusCode, messages, resource, uri, error = '') => ({
//   status: 'error',
//   statusCode,
//   error: !error ? responseCode[statusCode] : error,
//   messages,
//   resource,
//   uri,
// });
